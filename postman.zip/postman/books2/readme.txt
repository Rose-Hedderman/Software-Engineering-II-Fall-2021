This is an introductory tutorial shows how one can run a simple flask app with templates. It also deploys the app on GCP.

Do NOT forget to include:
- "venv" inside ".gitignore" to prevent pushing virtual environment to remote repo
- "requirements.txt"

